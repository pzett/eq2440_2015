/** Automatically generated file. DO NOT MODIFY */
package se.kth.android.FrameWork.NCTele;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}