/** Automatically generated file. DO NOT MODIFY */
package se.kth.android.FrameWork;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}