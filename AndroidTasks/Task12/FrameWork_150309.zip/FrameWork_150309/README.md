FrameWork
=========

Android software framework for student projects on smartphones
